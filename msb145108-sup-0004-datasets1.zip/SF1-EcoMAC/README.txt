Ecoli-compendium-assembly-quantilenorm.txt is the EcoMAC matrix containing the 2,198 gene expression profiles of E. coli. The dimensions are: 4,189 genes x 2,198 microarrays.

numbering_arrays-compendium.txt is a text file describing the columns of EcoMAC (2,198 arrays). See more information in the Supplementary File 2.

numbering_assembly-tfs-enzymes-genes.txt is a text file containing the gene names of EcoMAC (4,189 genes).